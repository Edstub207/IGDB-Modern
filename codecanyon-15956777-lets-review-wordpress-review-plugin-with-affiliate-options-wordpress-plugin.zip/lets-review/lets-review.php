<?php
/*
Plugin Name: Let's Review
Plugin URI: http://codecanyon.net/user/cubell
Author: Cubell
Author URI: http://codecanyon.net/user/cubell
Description: The ultimate review plugin for WordPress
Version: 1.2
License: http://codecanyon.net/licenses/regular_extended
License URI: http://codecanyon.net/licenses/regular_extended
Requires at least: 4.4
Tested up to: 4.5.2
Text Domain: lets-review
Domain Path: /languages/
*/

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Let's Review's core class
 */
require plugin_dir_path( __FILE__ ) . 'inc/class-lets-review.php';

/**
* Initialize the class
*
* @since 1.0.0
*/
if ( ! function_exists( 'lets_review_init' ) ) {
	
	function lets_review_init() {
		if ( class_exists('Lets_Review') ) {
			new Lets_Review;
		}
	}
}

lets_review_init();