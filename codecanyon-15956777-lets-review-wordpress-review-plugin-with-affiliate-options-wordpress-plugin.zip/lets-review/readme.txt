/*
Plugin Name: Let's Review
Plugin URI: http://codecanyon.net/user/cubell
Author: Cubell
Author URI: http://codecanyon.net/user/cubell
Description: The ultimate review plugin for WordPress
Version: 1.0
License: http://codecanyon.net/licenses/regular_extended
License URI: http://codecanyon.net/licenses/regular_extended
Requires at least: 4.4
Tested up to: 4.5
Text Domain: lets-review
Domain Path: /languages/
*/

/* CHANGELOG */

= 1.0 =
* Initial release